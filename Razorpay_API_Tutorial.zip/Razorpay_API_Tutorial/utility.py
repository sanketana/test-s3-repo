import razorpay
import json
import time
import calendar
import datetime
import pandas as pd
import configparser


def listify(mylist):
	list_str = '['
	for i in range(len(mylist) - 1):
		list_str += "'" + mylist[i] + "', "
	list_str += "'" + mylist[len(mylist) - 1] + "']"

	return(list_str)		

def get_invoice_details(invoice_id):
	invoice_detail = client.invoice.fetch(invoice_id)
	return invoice_detail

def get_invoice_item(invoice_id):
	invoice_det = get_invoice_details(invoice_id)
	line_items = invoice_det['line_items']
	line_item = line_items[0]
	item_id = line_item['item_id']
	amount = line_item['amount'] / 100
	currency = line_item['currency']
	item_dict = {
		'item_id' : item_id,
		'currency': currency,
		'amount' : amount
	}
	return(item_dict)




if __name__ == '__main__':

	#Test Customer and Item Id
	#cust_id = 'cust_FjAtfEh8gPpPWj'
	#itm_id = 'item_Gh7cz3TZhnF7cZ'

	config_file = 'invoicing.ini'
	config = configparser.ConfigParser()
	config.read(config_file)

	key_id = config.get('secrets', 'key_id')
	key_secret = config.get('secrets', 'key_secret')



	client = razorpay.Client(auth=(key_id, key_secret))
	client.set_app_details({"title" : "Sanketana Invoicing", "version" : "0.1"})	



	# TOOLKIT - Do Not Delete!!
	#issue_invoice()	
	print(get_invoice_item('inv_Ir4ap7FAKw6zdH'))
	#delete_invoice( ['inv_I7KTRSdSTRX72I'])
