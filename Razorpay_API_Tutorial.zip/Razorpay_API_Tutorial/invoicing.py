import razorpay
import json
import time
import calendar
import datetime
import pandas as pd
import logging
import configparser



def create_invoice(year_mon_str, customer_id, item_id, quantity, comment, currency):
	#create invoice for individual customer
	#year_mon_str format: YYYYMM
	invoice_date = datetime.datetime.strptime(year_mon_str, '%Y%m')
	invoice_prefix = invoice_date.strftime('%b').upper() + invoice_date.strftime('%Y')
	created_date = int(time.time())
	invoice_number = invoice_prefix + "_" + str(created_date)
	description =  invoice_date.strftime('%B %Y') + " Fee"

	DATA = {
	  "type": "invoice",
	  "description": description,
	  "invoice_number": invoice_number,
	  "date": created_date,
	  "customer_id": customer_id,
	  "line_items": [
	    {
	      "item_id": item_id,
	      "quantity": quantity
	    }
	  ],
	  "comment": comment,
	  "draft": "1",
	  "currency": currency
	}

	status = client.invoice.create(data=DATA)

	return status


def invoice_batch(year_mon, input_file, log_file):

	count = 0
	errors = 0
	invoice_list = []

	df = pd.read_csv(input_file)

	#filter row that dont need to be generated
	df1 = df.loc[df['Generate'] != 'N']

	#replace nulls with blank string
	dfx = df1.fillna('')		
	#iterate through the dataframe

	logger.info("Starting Invoicing Batch for period: %s" % (year_mon))

	for index, row in dfx.iterrows():
		cust_id = row['Customer_Id']
		itm_id = row['Item_Id']
		qty = int(row['Qty'])
		comment = row['Comment']
		currency = row['Currency']

		logger.info("API Call for Customer Id: %s Item Id: %s Quantity: %s Comment: %s" % (cust_id, itm_id, qty, comment))
		try: 
			status = create_invoice(year_mon, cust_id, itm_id, qty, comment, currency)
			logger.info("Invoice generated: " + status['id'])
			invoice_list.append(status['id'])
			count += 1
		except Exception as err:
			logger.error("Runtime error: " + repr(err) + " Customer Id: " + cust_id)
			errors += 1

		#Sleep to avoid timeout errors	
		time.sleep(1)
	
	logger.info("Done! " + str(count) + " Invoices generated. " + str(errors) + " errors encountered.")	
	logger.info("List of Invoice id generated: " + listify(invoice_list))	

	return ("Done! " + str(count) + " Invoices generated. " + str(errors) + " errors encountered.")


def delete_invoice(invoice_list):

	count = 0
	for invoice_id in invoice_list:
		try:
			status = client.invoice.delete(invoice_id)
			count += 1
			logger.info("Invoice deleted: " + invoice_id)		
		except Exception as err:
			logger.error("Runtime error: " + repr(err) + "Invoice Id: " + invoice_id)	

	logger.info(str(count) + " Invoices deleted")	

def listify(mylist):
	list_str = '['
	for i in range(len(mylist) - 1):
		list_str += "'" + mylist[i] + "', "
	list_str += "'" + mylist[len(mylist) - 1] + "']"

	return(list_str)		

def get_invoice_details(invoice_id):
	invoice_detail = client.invoice.fetch(invoice_id)
	return invoice_detail

def get_invoice_item(invoice_id):
	invoice_det = get_invoice_details(invoice_id)
	line_items = invoice_det['line_items']
	line_item = line_items[0]
	item_id = line_item['item_id']
	amount = line_item['amount'] / 100
	currency = line_item['currency']
	item_dict = {
		'item_id' : item_id,
		'currency': currency,
		'amount' : amount
	}
	return(item_dict)

def issue_invoice(inv_list):
	count = 0
	errors = 0

	logger.info("Starting Invoice Issuing for period: %s" % (year_mon))

	for inv_id in inv_list:
		logger.info("Issuing Invoice for the draft Invoice Id: %s" % (inv_id))
		try: 
			status = client.invoice.issue(inv_id)
			logger.info("Invoice issued: " + status['id'])
			count += 1
		except Exception as err:
			logger.error("Runtime error: " + repr(err) + " Draft Invoice Id: " + inv_id)
			errors += 1

		#Sleep to avoid timeout errors	
		time.sleep(1)
	
	logger.info("Done! " + str(count) + " Invoices issued. " + str(errors) + " errors encountered.")	


if __name__ == '__main__':

	#Test Customer and Item Id
	#cust_id = 'cust_FjAtfEh8gPpPWj'
	#itm_id = 'item_Gh7cz3TZhnF7cZ'

	config_file = 'invoicing.ini'
	config = configparser.ConfigParser()
	config.read(config_file)

	key_id = config.get('secrets', 'key_id')
	key_secret = config.get('secrets', 'key_secret')
	year_mon = config.get('inputs', 'year_mon')
	file_name = config.get('inputs', 'file_name')
	log_file_prefix = config.get('inputs', 'log_file_prefix')
	disable_logging = config.get('inputs', 'disable_logging')


	client = razorpay.Client(auth=(key_id, key_secret))
	client.set_app_details({"title" : "Sanketana Invoicing", "version" : "0.1"})	

	#Setting up input variables	
	log_file_name = log_file_prefix + str(int(time.time())) + ".log"



	#setting up logger
	logging.basicConfig(filename=log_file_name, 
						format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s', 
						datefmt='%m-%d %H:%M',
						filemode='w') 	
	logger = logging.getLogger()
	logger.setLevel(logging.DEBUG)
	console = logging.StreamHandler()
	console.setLevel(logging.INFO)
	formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
	console.setFormatter(formatter)
	logging.getLogger().addHandler(console)	
	#Set disable logging = True in ini file to disable logging
	logger.disabled = (disable_logging != 'False')

	#invoice_batch(year_mon, file_name, log_file_name)


	# TOOLKIT - Do Not Delete!!
	invoice_list = ['inv_J2DM4BXl8fvTJz', 'inv_J2DM5r4eOgHIma', 'inv_J2DM7WbKkjkiA5', 'inv_J2DM9DBihd9RrP', 'inv_J2DMAqKkGc7TUY', 'inv_J2DMCRDiTmMs8v', 'inv_J2DME2uz7QJQau', 'inv_J2DMFe0JjcHBDI', 'inv_J2DMHLjIDl5Wg0', 'inv_J2DMIzRn4HRoBk', 'inv_J2DMKcfkaYnJFf', 'inv_J2DMMD9GvEsFDt', 'inv_J2DMNwWrpyc5R4', 'inv_J2DMPZJMZX7m13', 'inv_J2DMR9AMMK3h4t', 'inv_J2DMSizyWuRvG9', 'inv_J2DMUKxHIkjGzt', 'inv_J2DMVvJ2hKFT9B', 'inv_J2DMXYoUAJLVYe', 'inv_J2DMZ9Pnb0rjkG', 'inv_J2DMaj7qvnQs5e', 'inv_J2DMcNz0eD4tk3', 'inv_J2DMe05uF7OOiv', 'inv_J2DMfbl1Gax2kR', 'inv_J2DMhBG5EY4JnY', 'inv_J2DMikARlXZK1y', 'inv_J2DMkMe9zoQ1Mn', 'inv_J2DMly29JhJzY5', 'inv_J2DMnaRmaLQpQo', 'inv_J2DMpBJA6HB9mJ', 'inv_J2DMqmjCPvmTQu', 'inv_J2DMsOOeU38xuT', 'inv_J2DMu1pVW0A08I', 'inv_J2DMvfzgiHo8HM', 'inv_J2DMxMTZ2Vr0Jc', 'inv_J2DMyyg9dsdybe', 'inv_J2DN0aqoYusIuK', 'inv_J2DN2DDxPcmNvT', 'inv_J2DN3mP2Vf56TN', 'inv_J2DN5PbvgU5RIC', 'inv_J2DN75RA3RdPCx', 'inv_J2DN8pVfOG5O9m', 'inv_J2DNAYNL9pO0R7', 'inv_J2DNCC1JgW78Ki', 'inv_J2DNDtA4peUJFA', 'inv_J2DNFX4aTEn84C', 'inv_J2DNH8eVmNGY2N', 'inv_J2DNIk06bS5yKr', 'inv_J2DNKLwDRstk7q', 'inv_J2DNLwuGCJIKMW', 'inv_J2DNNaAHZmHcOK']
	issue_invoice(invoice_list)	
	#print(get_invoice_details('inv_IrrQdBkPIRgN49'))
	#delete_invoice( ['inv_I7KTRSdSTRX72I'])



# TODO: Additional improvements and features for next version
# Issue Draft invoice
# Retry until successful, summary report after batch cycle
# Amount receivables for a given month, Customer list of Invoice not paid
# Auto-delete old logs
# Currency = blank as default for INR